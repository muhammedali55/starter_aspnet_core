using Core.Entities;
namespace Entity.Entities
{
  public partial class tblodeme:IEntity
  {
       public int Id { get; set; }
  }
}
