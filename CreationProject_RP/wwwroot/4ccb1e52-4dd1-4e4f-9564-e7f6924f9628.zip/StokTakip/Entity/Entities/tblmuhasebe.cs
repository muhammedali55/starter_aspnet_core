using Core.Entities;
namespace Entity.Entities
{
  public partial class tblmuhasebe:IEntity
  {
       public int Id { get; set; }
  }
}
