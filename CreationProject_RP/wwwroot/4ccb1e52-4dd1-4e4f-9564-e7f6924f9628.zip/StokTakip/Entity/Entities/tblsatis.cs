using Core.Entities;
namespace Entity.Entities
{
  public partial class tblsatis:IEntity
  {
       public int Id { get; set; }
  }
}
