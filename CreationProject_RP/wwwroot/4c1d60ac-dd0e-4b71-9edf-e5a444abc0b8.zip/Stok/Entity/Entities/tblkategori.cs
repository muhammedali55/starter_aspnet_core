using Core.Entities;
namespace Entity.Entities
{
  public partial class tblkategori:IEntity
  {
       public int Id { get; set; }
  }
}
