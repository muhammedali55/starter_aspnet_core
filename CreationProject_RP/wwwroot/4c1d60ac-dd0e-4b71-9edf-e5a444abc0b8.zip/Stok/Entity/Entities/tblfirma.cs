using Core.Entities;
namespace Entity.Entities
{
  public partial class tblfirma:IEntity
  {
       public int Id { get; set; }
  }
}
