namespace Core.Entities
{
  public interface IEntity
  {
  }
}
