using Core.DataAccess;
using Entity.Entities;
namespace DataAccess.Abstract
{
  public interface ItblurunDal : IEntityRepository<tblurun>
  {
  }
}
