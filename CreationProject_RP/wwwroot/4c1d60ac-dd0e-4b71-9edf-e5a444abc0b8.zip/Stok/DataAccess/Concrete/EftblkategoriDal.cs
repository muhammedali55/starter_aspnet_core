using Core.DataAccess;
using Entity.Entities;
using DataAccess.Abstract;
namespace DataAccess.Concrete
{
  public class EftblkategoriDal : EfEntityRepositoryBase<tblkategori, DbMusteriContext>, ItblkategoriDal
  {
  }
}
