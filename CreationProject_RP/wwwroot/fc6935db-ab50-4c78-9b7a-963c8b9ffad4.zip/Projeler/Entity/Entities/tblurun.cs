using Core.Entities;
namespace Entity.Entities
{
  public partial class tblurun:IEntity
  {
       public int Id { get; set; }
  }
}
