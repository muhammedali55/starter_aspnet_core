using Core.Entities;
namespace Entity.Entities
{
  public partial class tblpersonel:IEntity
  {
       public int Id { get; set; }
  }
}
