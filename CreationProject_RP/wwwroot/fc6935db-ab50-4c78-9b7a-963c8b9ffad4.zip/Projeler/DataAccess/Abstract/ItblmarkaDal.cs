using Core.DataAccess;
using Entity.Entities;
namespace DataAccess.Abstract
{
  public interface ItblmarkaDal : IEntityRepository<tblmarka>
  {
  }
}
