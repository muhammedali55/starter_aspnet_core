using Core.DataAccess;
using Entity.Entities;
namespace DataAccess.Abstract
{
  public interface ItblmodelDal : IEntityRepository<tblmodel>
  {
  }
}
