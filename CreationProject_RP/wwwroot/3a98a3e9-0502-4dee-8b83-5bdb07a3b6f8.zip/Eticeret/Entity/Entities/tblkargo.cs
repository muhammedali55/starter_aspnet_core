using Core.Entities;
namespace Entity.Entities
{
  public partial class tblkargo:IEntity
  {
       public int Id { get; set; }
  }
}
