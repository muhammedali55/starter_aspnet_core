using Core.DataAccess;
using Core.Entities;
using DataAccess.Abstract;;
namespace DataAccess.Concrete
{
  public class EftblmodelDal : EfEntityRepositoryBase<tblmodel, DBMusteri>, ItblmodelDal
  {
  }
}
