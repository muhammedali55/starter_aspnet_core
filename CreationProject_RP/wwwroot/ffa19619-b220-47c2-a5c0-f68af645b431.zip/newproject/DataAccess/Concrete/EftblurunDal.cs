using Core.DataAccess;
using Core.Entities;
using DataAccess.Abstract;;
namespace DataAccess.Concrete
{
  public class EftblurunDal : EfEntityRepositoryBase<tblurun, DBMusteri>, ItblurunDal
  {
  }
}
