using Core.DataAccess;
using Core.Entities;
namespace DataAccess.Abstract
{
  public interface ItblmodelDal : IEntityRepository<tblmodel>
  {
  }
}
