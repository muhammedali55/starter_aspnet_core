using Core.DataAccess;
using Core.Entities;
namespace DataAccess.Abstract
{
  public interface ItblurunDal : IEntityRepository<tblurun>
  {
  }
}
