using Core.Entities;
namespace Entity.Entities
{
  public partial class tblmarka:IEntity
  {
       public int Id { get; set; }
  }
}
