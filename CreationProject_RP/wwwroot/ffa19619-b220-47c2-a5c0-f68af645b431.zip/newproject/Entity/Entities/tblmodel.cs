using Core.Entities;
namespace Entity.Entities
{
  public partial class tblmodel:IEntity
  {
       public int Id { get; set; }
  }
}
